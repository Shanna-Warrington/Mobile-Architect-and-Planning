package com.zybooks.myinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GridActivity extends AppCompatActivity {

    //Variables
    EditText number, name, amount;
    Button insert, update, delete, view;
    dbHelper db;

    //Code that will start on creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        //Setting up what id the System will use
        number = findViewById(R.id.itemNumber);
        name = findViewById(R.id.item);
        amount = findViewById(R.id.itemAmount);


        insert = findViewById(R.id.addButton);
        update = findViewById(R.id.updateButton);
        delete = findViewById(R.id.deleteButton);
        view = findViewById(R.id.searchButton);
        db = new dbHelper(this);

        //inserting an item into the inventory
        insert.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                String numberTXT = number.getText().toString();
                String nameTXT = name.getText().toString();
                String amountTXT = amount.getText().toString();

                boolean checkinsertdata = db.insertData(numberTXT, nameTXT, amountTXT);
                if(checkinsertdata == true){
                    Toast.makeText(GridActivity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(GridActivity.this, "Entry Not Inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Updating a pre-existing item
        update.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                String numberTXT = number.getText().toString();
                String nameTXT = name.getText().toString();
                String amountTXT = amount.getText().toString();

                boolean checkupdatedata = db.updatedata(numberTXT, nameTXT, amountTXT);
                if(checkupdatedata == true){
                    Toast.makeText(GridActivity.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(GridActivity.this, "Entry Not Updated", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Deleting an item
        delete.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                String numberTXT = number.getText().toString();

                boolean checkdeletedata = db.deletedata(numberTXT);
                if(checkdeletedata == true){
                    Toast.makeText(GridActivity.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(GridActivity.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Viewing the items
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = db.getdata();
                if(res.getCount() == 0){
                    Toast.makeText(GridActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append(("number: " + res.getString(0) + "\n"));
                    buffer.append(("item: " + res.getString(1) + "\n"));
                    buffer.append(("amount: " + res.getString(2) + "\n\n"));
                }
            }
        });
    }
}

