package com.zybooks.myinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    //Variables
    private EditText eEmail;
    private EditText ePassword;
    private Button btnLogin;
    private Button btnCreate;

    //Email and password for testing
    private final String TestEmail = "Admin@SNHU.edu";
    private final String TestPassword = "Admin";

    boolean isValid = false;

    //Code that will start on creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Setting up what id the System will use
        eEmail = findViewById(R.id.Email);
        ePassword = findViewById(R.id.userPassword);
        btnLogin = findViewById(R.id.buttonLogin);
        btnCreate = findViewById(R.id.createButton);

        btnLogin.setOnClickListener(new View.OnClickListener() {

            //Setting up what code will run when the login button is pressed
            @Override
            public void onClick(View view) {

                String inputEmail = eEmail.getText().toString();
                String inputPassword = ePassword.getText().toString();

                //Response if email or password is empty
                if(inputEmail.isEmpty() || inputPassword.isEmpty()){

                    Toast.makeText(MainActivity.this, "Please enter your email and password", Toast.LENGTH_SHORT).show();

                }else{

                    //Validates email and password entered
                    isValid = validate(inputEmail, inputPassword);

                    if(!isValid){

                        Toast.makeText(MainActivity.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();

                    }else{

                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(MainActivity.this, GridActivity.class);
                        startActivity(intent);

                    }

                }
            }
        });

        //Setting up what code will run when the login button is pressed
        btnCreate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                String inputEmail = eEmail.getText().toString();
                String inputPassword = ePassword.getText().toString();

                //Response if email or password is empty
                if(inputEmail.isEmpty() || inputPassword.isEmpty()){

                    Toast.makeText(MainActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();

                }else{

                    //Validates email and password entered
                    isValid = validate(inputEmail, inputPassword);

                    if(!isValid){

                        Toast.makeText(MainActivity.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();

                    }else{

                        Toast.makeText(MainActivity.this, "New Account Successful", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(MainActivity.this, GridActivity.class);
                        startActivity(intent);

                    }

                }
            }
        });

    }

    //Compares the input to the test email and password
    private boolean validate(String email, String password){

        if(email.equals(TestEmail) && password.equals(TestPassword)){
            return true;
        }

        return false;
    }

}

