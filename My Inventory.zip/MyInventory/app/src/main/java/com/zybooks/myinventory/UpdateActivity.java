package com.zybooks.myinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class UpdateActivity extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 2;

    public UpdateActivity(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }


    //Setting up the variables for the inventory table
    private static final class InventoryTable {
        private static final String TABLE = "Inventory";
        private static final String COL_Item = "Number";
        private static final String COL_Name = "Name";
        private static final String COL_Qty = "Quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(InventoryTable.TABLE + InventoryTable.COL_Item +
                InventoryTable.COL_Name + InventoryTable.COL_Qty);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    //Adding an item to the table
    public boolean addItem() {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_Item, "mNumber");
        values.put(InventoryTable.COL_Name, "mName");
        values.put(InventoryTable.COL_Qty, "mAmount");

        long inventoryId = db.insert(InventoryTable.TABLE, null, values);
        if(inventoryId == -1) {
            return false;
        }else{
            return true;
        }
    }

    //Updating an item on the table
    public boolean updateItem() {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_Name, "mName");
        values.put(InventoryTable.COL_Qty, "mAmount");
        Cursor cursor = db.rawQuery("Select * from InventoryTable where mNumber=?", new String[]{"mNumber"});
        if (cursor.getCount() > 0) {
            long inventoryId = db.update(InventoryTable.TABLE, values, "mNumber=?", new String[]{"mNumber"});
            if (inventoryId == -1) {
                return false;
            } else {
                return true;
            }
        }else{
            return false;
        }
    }

    //Deleting an item from the table
    public boolean deleteItem() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from InventoryTable where mNumber=?", new String[]{"mNumber"});
        if (cursor.getCount() > 0) {
            long inventoryId = db.delete(InventoryTable.TABLE, "mNumber=?", new String[]{"mNumber"});
            if (inventoryId == -1) {
                return false;
            } else {
                return true;
            }
        }else{
            return false;
        }
    }

    //Getting data from the cursor
    public Cursor getdata() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from InventoryTable", null);
        return cursor;
    }
}
