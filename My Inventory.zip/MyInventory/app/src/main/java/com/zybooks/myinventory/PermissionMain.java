package com.zybooks.myinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PermissionMain extends AppCompatActivity {

    //Variables for buttons used
    Button abutton;
    Button dbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.permissions);

        abutton = findViewById(R.id.acceptbutton);
        dbutton = findViewById(R.id.denybutton);

        abutton.setOnClickListener(new View.OnClickListener(){
            //Checking for permissions already granted in certain versions
            @Override
            public void onClick(View view) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if (getApplicationContext().checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED)
                    {
                        Toast.makeText(PermissionMain.this, "Permissions Granted", Toast.LENGTH_SHORT).show();
                    }else{
                        requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 1);
                    }
                }else{
                    Toast.makeText(PermissionMain.this, "Permissions Granted", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    //Showing whether permissions were granted or not
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(PermissionMain.this, "Permissions Granted", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(PermissionMain.this, "Permissions Denied", Toast.LENGTH_SHORT).show();
            }
    }
}

}